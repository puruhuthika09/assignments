//
//  ViewController.swift
//  VowelTester
//
//  Created by Yerragunta,Puruhuthika on 8/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var outputOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func BtnClicked(_ sender: UIButton) {
        //Read the input text and assign it to a var
        
        var input = inputOL.text!
        
        input.lowercased()
        
        //check if the text is having vowels or not
        if(input.contains("A") || input.contains("E") || input.contains("I") || input.contains("O") || input.contains("U")){
            outputOL.text = "The \(input) has vowels!"
        }
        else{
            outputOL.text = "\(input) no vowels!"
        }
        
        //if the text has a e i o u then print "original text" else  "no vowels"
        
        
    }
}

