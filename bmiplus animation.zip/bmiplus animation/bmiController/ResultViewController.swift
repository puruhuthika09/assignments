//
//  ResultViewController.swift
//  bmiController
//
//  Created by Y Puruhuthika on 11/4/23.
//

import UIKit

class ResultViewController: UIViewController {

    var height = ""
    var weight = ""
    
    var BMI = 0.0
    var imageName = ""
    
    @IBOutlet weak var displayHeightOL: UILabel!
    
    
    @IBOutlet weak var displayWeightOL: UILabel!
    
    
    @IBOutlet weak var displayBMI: UILabel!
    
 
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayWeightOL.text! += weight
        displayHeightOL.text! += height
        displayBMI.text! += String(BMI)
        
        displayImage.image = UIImage(named: imageName)
        displayImage.frame.origin.x = view.frame.maxX
    }

  
    
    //yes this code works for display and blink
//    override func viewDidAppear(_ animated: Bool) {
//            super.viewDidAppear(animated)
//
//            // Perform the image-specific animation
//            animateResultImage(imageName)
//        }
//
//        func animateResultImage(_ imageName: String) {
//            // Make the current image as opaque (alpha is zero)
//            displayImage.alpha = 0
//
//            // Assign the new image as animation and make it transparent (alpha should be 1)
//            UIView.animate(withDuration: 1, delay: 0.5, options: [.autoreverse, .repeat], animations: {
//                self.displayImage.alpha = 1
//                self.displayImage.image = UIImage(named: imageName)
//            })
//        }
    
    
    //4
//    override func viewDidAppear(_ animated: Bool) {
//            super.viewDidAppear(animated)
//
//            // Perform the image-specific animation
//            animateResultImage(imageName)
//        }
//
//        func animateResultImage(_ imageName: String) {
//            // Move the image view outside of the screen view
//            displayImage.frame.origin.x = view.frame.maxX
//
//            // Animate the image coming into the screen
//            UIView.animate(withDuration: 1, animations: {
//                self.displayImage.center.x = self.view.center.x
//            }) { _ in
//                // Animation completion block
//                // Make the current image as opaque (alpha is zero)
//                self.displayImage.alpha = 0
//
//                // Assign the new image as animation and make it transparent (alpha should be 1)
//                UIView.animate(withDuration: 1, delay: 0.5, options: [.autoreverse, .repeat], animations: {
//                    self.displayImage.alpha = 1
//                    self.displayImage.image = UIImage(named: imageName)
//                })
//            }
//        }
    //but working for cemter
//    override func viewDidAppear(_ animated: Bool) {
//            super.viewDidAppear(animated)
//            
//            // Animate the image coming from the right side of the screen and staying there
//            UIView.animate(withDuration: 1, animations: {
//                self.displayImage.frame.origin.x = self.view.frame.maxX - self.displayImage.frame.width
//            }) { _ in
//                // Animation completion block
//                // Make the current image as opaque (alpha is zero)
//                self.displayImage.alpha = 0
//                
//                // Assign the new image as animation and make it transparent (alpha should be 1)
//                UIView.animate(withDuration: 1, delay: 0.5, animations: {
//                    self.displayImage.alpha = 1
//                    self.displayImage.image = UIImage(named: self.imageName)
//                })
//            }
//        }
//    //9
//    override func viewDidAppear(_ animated: Bool) {
//            super.viewDidAppear(animated)
//
//            // Animate the image coming from the right side of the screen to the center and staying there
//            UIView.animate(withDuration: 1, animations: {
//                self.displayImage.center.x = self.view.center.x
//            }) { _ in
//                // Animation completion block
//                // Make the current image as opaque (alpha is zero)
//                self.displayImage.alpha = 0
//
//                // Assign the new image as animation and make it transparent (alpha should be 1)
//                UIView.animate(withDuration: 1, delay: 0.5, animations: {
//                    self.displayImage.alpha = 1
//                    self.displayImage.image = UIImage(named: self.imageName)
//                })
//            }
//        }
    //yes it is working for phone out of screen
    override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)

            // Animate the image coming from the right side of the screen to the center
            UIView.animate(withDuration: 1, animations: {
                self.displayImage.center.x = self.view.center.x
            })
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
}
