//
//  ViewController.swift
//  bmiController
//
//  Created by Y Puruhuthika on 11/4/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

//    var bodymassindex = 0.0
    
    var BMI = 0.0
    
    var imageName = ""
    
    @IBOutlet weak var heightOL: UITextField!
    
    
    @IBOutlet weak var weightOL: UITextField!
    
    
    @IBAction func BMIBTN(_ sender: UIButton) {
       var height = Double(heightOL.text!)
        
        var weight = Double(weightOL.text!)
        
        var bodymassindex = (weight!*703)/(height!*height!)
        
         BMI = Double(round(100 * bodymassindex)/100)
        
        if(BMI < 18.45){
            imageName = "underweight"
        }
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as!
            ResultViewController
            destination.weight=weightOL.text!
            destination.height = heightOL.text!
            destination.BMI = BMI
            destination.imageName = imageName
            
        }
    }
    
    
    
    
    
    
    
}

