//
//  productViewController.swift
//  exam3_App
//
//  Created by Y Puruhuthika on 11/30/23.
//

import UIKit

class productViewController: UIViewController {

    var contacts : [String] = []
    
    @IBOutlet weak var displayLabelOL: UILabel!
    
    @IBOutlet weak var displayemailOL: UILabel!
    
    
    
    @IBOutlet weak var displaynumberOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
                    displayLabelOL.text = contacts[0]
                    displayemailOL.text = "Email: \(contacts[1])"
                   displaynumberOL.text = "Phone: \(contacts[2])"
                
        
      //  displayLabelOL.text = " \((contacts[0]))  \((contacts[1]))  \((contacts[2]))"
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
