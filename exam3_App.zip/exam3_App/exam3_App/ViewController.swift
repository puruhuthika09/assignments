//
//  ViewController.swift
//  exam3_App
//
//  Created by Y Puruhuthika on 11/30/23.
//

import UIKit


class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return the no.of products  [count of an array]
        return contacts.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //create the cell , pouplate the cell and  return the cell
        var cell = displayTableView.dequeueReusableCell(withIdentifier: "reusableCell",for: indexPath)
        cell.textLabel?.text = contacts[indexPath.row][0]
        return cell
        
        
    }

    var contacts = [
            ["John Doe", "john.doe@example.com", "123-456-7890"],
            ["Jane Smith", "jane.smith@example.com", "987-654-3210"],
            ["Bob Johnson", "bob.johnson@example.com", "555-123-4567"],
        ]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        displayTableView.delegate = self
        displayTableView.dataSource = self
    }

    @IBOutlet weak var displayTableView: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if(transition  == "ProductDetails"){
            let destination = segue.destination as!
            productViewController
            destination.contacts =
            contacts[(displayTableView.indexPathForSelectedRow?.row)!]
            
            
        }
        
    }
}

