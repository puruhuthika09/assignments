//
//  ViewController.swift
//  basic app
//
//  Created by Y PURUHUTHIKA on 10/3/23.
//

import UIKit

class ViewController: UIViewController {
    //imageNumber = 0
    @IBOutlet weak var imageview: UIImageView!
    
    @IBOutlet weak var input1OL: UITextField!
    
    
    @IBOutlet weak var input2OL: UITextField!
    
    @IBOutlet weak var resultLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    //var laptopImages = ["laptop1.jpg", "laptop2.jpg", "laptop3.jpg", "laptop4.jpg"]

//
//    lazy var caseInsensitiveLaptopNames: [String: String] = {
//            var dictionary = [String: String]()
//            for (key, value) in laptopImages {
//                dictionary[key.lowercased()] = value
//            }
//            return dictionary
//        }()
    
    @IBAction func btnClicked(_ sender: UIButton) {
        var laptopName = input1OL.text!
        var price = input2OL.text!
        
        if let pricee = Double(price) {
            
            let tax = pricee * 0.10
            let total = tax + (pricee)
           // if let laptopName = input1OL.text{
              //  let lowercaseLaptopName = laptopName.lowercased()
//                if   let imageName = [lowercaseLaptopName] {
                    
                    
                        
                        // Implement printing here, including laptop name, price, and the displayed image
                   // }
                if let laptopName = input1OL.text?.lowercased() {
                                    var imageName: String?
                                    
                                    if laptopName == "dell" {
                                        imageName = "laptop2.jpg"
                                    } else if laptopName == "lenovo" {
                                        imageName = "laptop4.jpg"
                                    } else if laptopName == "hp" {
                                        imageName = "laptop1.jpg"
                                    }else if laptopName == "macbook pro"{
                                        imageName = "laptop3.jpg"
                                    }
                    
                                    if let imageName = imageName, let image = UIImage(named: imageName) {
                                        imageview.image = image
                                        // Implement printing here, including laptop name, price, and the displayed image
                                    } else {
                                        // Handle the case where the laptop name is not found
                                        // You can show an error message or do something else as needed
                                    }
                                }
                            
                    
                    
                    
                    
                    //updateDisplay(imageNumber)
                    resultLabel.text = "Name:\(laptopName),price:\(pricee),tax:\(tax),total:\(total)"
                }
                
            }
        
    
    
    @IBAction func resetBtn(_ sender: UIButton) {
        input1OL.text = ""
        input2OL.text = ""
        resultLabel.text = ""
        imageview.image = nil
        
        
    }
    
}



