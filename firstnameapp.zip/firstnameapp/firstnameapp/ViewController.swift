//
//  ViewController.swift
//  firstnameapp
//
//  Created by Yerragunta,Puruhuthika on 8/29/23.
//

import UIKit

class ViewController: UIViewController {
    
    

    @IBOutlet weak var inputOL: UITextField!
    
    
    @IBOutlet weak var lastinputOL: UITextField!
    
    @IBOutlet weak var labelOL: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
        
    }
    
    

    @IBAction func submitbtnOL(_ sender: UIButton) {
        var firstname = inputOL.text!
        var lastname = lastinputOL.text!
        
        labelOL.text = "Hello,\(firstname) \(lastname)"
        
        
        
        
        
        
    }
    
}

