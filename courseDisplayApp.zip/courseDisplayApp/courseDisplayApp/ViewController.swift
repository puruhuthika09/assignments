//
//  ViewController.swift
//  courseDisplayApp
//
//  Created by Y PURUHUTHIKA on 9/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageDisplay: UIImageView!
    
    
    @IBOutlet weak var crsNumber: UILabel!
    
    @IBOutlet weak var crsName: UILabel!
    
    
    
    @IBOutlet weak var semOffered: UILabel!
    @IBOutlet weak var prevBtnOL: UIButton!
    
    @IBOutlet weak var nextBtnOL: UIButton!
    //create an array
    var courses = [["img01","44542","Network Security","Fall 2023"],
                   ["img02","44643","ios","Fall 2023"],
                   ["img03","44555","Data Streaming","Summer 2023"]]
    var imageNumber = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //prev btn is disabled
        prevBtnOL.isEnabled = false
        //display the first course details
       // crsNumber.text = courses[0][1]
       // crsName.text = courses[0][2]
       // semOffered.text = courses[0][3]
       // imageDisplay.image = UIImage(named:courses[0][0])
        updateDisplay(imageNumber)
        
        
        
    }

    
    @IBAction func prevBtnClicked(_ sender: UIButton) {
        
    //next btn should be enabled
        prevBtnOL.isEnabled = true
    //decrement the imageNumber
        imageNumber -= 1
        //update the display using method
        updateDisplay(imageNumber)
    // If we reach begining of the array ,prev btn should be disabld
        if(imageNumber == 0){
            prevBtnOL.isEnabled = false
        }
        
        
    }
    
    @IBAction func nextBtnClicked(_ sender: UIButton) {
        
        //prev btn should be disabled
        
        prevBtnOL.isEnabled = true
        //next element in the course array must be displayed
        imageNumber += 1
        //crsNumber.text = courses[imageNumber][1]
        //crsName.text = courses[imageNumber][2]
        //semOffered.text = courses[imageNumber][3]
        //imageDisplay.image = UIImage(named: courses[imageNumber][0])
        
        //call the updateDisplay method
        updateDisplay(imageNumber)
        
        
        //when u reach the end of the array,next btn should be disabled
        if(imageNumber == courses.count-1){
            nextBtnOL.isEnabled = false
            
        }
        
        
        
        
    }
    func updateDisplay(_ imageNumber:Int){
     
        crsNumber.text = courses[imageNumber][1]
        crsName.text = courses[imageNumber][2]
        semOffered.text = courses[imageNumber][3]
        imageDisplay.image = UIImage(named: courses[imageNumber][0])
        
        
        
    }
}

