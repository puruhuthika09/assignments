//
//  ViewController.swift
//  DiscountApp
//
//  Created by Y PURUHUTHIKA on 9/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var input1OL: UITextField!
    
    @IBOutlet weak var input2OL: UITextField!
    
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var INPUT2OL: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func subitBtn(_ sender: UIButton) {
        if let amountText = input1OL.text, let discountText = input2OL.text
        {
                    if let amount = Double(amountText), let discount = Double(discountText)
            {
                        let tip = amount * (discount / 100.0)
                        // Calculate tip based on discount percentage
                        let disc = amount - tip
                        resultLabel.text = "Tip: $\(tip)"
                    }
            
            
        }
        
    }
    
}
