//
//  ViewController.swift
//  BearcatMotel
//
//  Created by Yerragunta,Puruhuthika on 10/5/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var roomOutlet: UITextField!
    
    
    @IBOutlet weak var membershipOL: UITextField!
    
   
    @IBOutlet weak var resultLabel: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func submitBtn(_ sender: UIButton) {
        var name = nameOutlet.text!
        var room = roomOutlet.text!
        var memberShip = membershipOL.text!
        var roomTypePrice : String
        var memberShipp : String
        
        
        
        if  room.contains("single-bed") || memberShip.contains("yes") || room.contains("double-bed") || memberShip.contains("yes"){
            let priceSingle = 74.99
            let priceDouble = 84.99
            //let pricee =  Double(price)
            let tax = priceSingle + 16.75
            let discount =  priceSingle * (5 / 100.0)
            
            
            
            if let roomName = roomOutlet.text?.lowercased() {
                var imageName: String?
                
                if roomName == "single-bed" {
                    imageName = "Single_Img.jpeg"
                    
                }else if roomName == "double-bed"{
                    imageName = "Double_Img.jpeg"
                }
                
                if let imageName = imageName, let image = UIImage(named: imageName) {
                    imageView.image = image
                    // Implement printing here, including laptop name, price, and the displayed image
                    resultLabel.text = "Dear\(name),\r  You have made a resevation at BearCat Model for a single-Bed at a$\(tax)including tax"

                }
            }
        }
        
    }
    
    @IBAction func resetBtn(_ sender: UIButton) {
        nameOutlet.text = ""
        roomOutlet.text = ""
        membershipOL.text = ""
        imageView.image = nil
        resultLabel.text = ""
        
    }
    
}

