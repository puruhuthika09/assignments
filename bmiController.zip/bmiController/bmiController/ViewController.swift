//
//  ViewController.swift
//  bmiController
//
//  Created by Yerragunta,Puruhuthika on 11/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var heightOL: UITextField!
    
    var result = 0.0
    var imageName  = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    
    
    
    @IBAction func resultBtn(_ sender: UIButton) {
        
        
        var weight = Double(weightOL.text!)
        var height = Double(heightOL.text!)
        
        
        result = (weight!/height!)*7.03
        
        
        
    }
        
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            var transition = segue.identifier
            if transition == "resultSegue"{
                var destination = segue.destination as!
                BMIViewController
                destination.weight=weightOL.text!
                destination.height = heightOL.text!
                destination.result = result
                destination.imageName = imageName
                
            }
        }
    }
    

