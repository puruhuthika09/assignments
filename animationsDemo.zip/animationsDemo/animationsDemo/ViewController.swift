//
//  ViewController.swift
//  animationsDemo
//
//  Created by Yerragunta,Puruhuthika on 10/24/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var imageView: UIImageView!
    
    
    @IBOutlet weak var happyOL: UIButton!
    
    
    @IBOutlet weak var sadOL: UIButton!
    
    
    
    @IBOutlet weak var angryOL: UIButton!
    
    
    
    @IBOutlet weak var shakeMeOL: UIButton!
    
    
    @IBOutlet weak var showOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    override func viewDidAppear(_ animated: Bool) {
        //Move the image view outside of the screen view
        
        imageView.frame.origin.x = view.frame.maxX
        //similarly move other components outside of the screen
        
        happyOL.frame.origin.x = view.frame.width
        
        sadOL.frame.origin.x = view.frame.width
        
        angryOL.frame.origin.x = view.frame.width
        
        shakeMeOL.frame.origin.x = view.frame.width
        
        
        
        
        
    }
    
    
    
    
    @IBAction func happyButtonClicked(_ sender: UIButton) {
        
        UpdateandAnimate("happy")
    }
   
    @IBAction func sadButtonClicked(_ sender: UIButton) {
        
        UpdateandAnimate("sad")
    }
    
    
    @IBAction func angryButtonClicked(_ sender: UIButton) {
        
        UpdateandAnimate("angry")
    }
    
    @IBAction func shakeMeButtonClicked(_ sender: UIButton) {
        
        var width = imageView.frame.width
        width += 40
        
        var height = imageView.frame.height
        height += 40
        
        var x = imageView.frame.origin.x - 20
        var y = imageView.frame.origin.y - 20
        
        //create a rectangle object
        var largerFrame  = CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1,delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 100,animations:{
            
            self.imageView.frame = largerFrame
            
        }
        )
        
    }
    
    
    @IBAction func showMeButtonClickled(_ sender: UIButton) {
        
        UIView.animate(withDuration: 1, animations: {
            self.imageView.center.x = self.view.center.x
            
            self.happyOL.center.x = self.view.center.x
            
            self.sadOL.center.x = self.view.center.x
            
            self.angryOL.center.x = self.view.center.x
            
            self.shakeMeOL.center.x = self.view.center.x
            
            
            
            
        })
        
        //Disable the showMe button
        showOL.isEnabled = false
    }
    
    func UpdateandAnimate(_ imageName:String){
        //Make the current image as opaque.(alpha is zero)
        UIView.animate(withDuration: 1, animations: {
            self.imageView.alpha = 0
        })
        // Assign the new image as animation and make it transparent.(alpha should be 1)
        UIView.animate(withDuration: 1, delay: 0.5,animations: {
            self.imageView.alpha = 1
            self.imageView.image = UIImage(named: imageName)
        })
        
        
    }
    
    
}

