//
//  ViewController.swift
//  Yerragunta_WordGuess
//
//  Created by Y PURUHUTHIKA on 10/16/23.
//

import UIKit

class ViewController: UIViewController {
    
    var input = [["airplane.jpg","AIRPLANE","Mode of Transport"],["banana.jpg","BANANA","Fruit"],["carrot.jpg","CARROT","Orange Vegetable"],["Dragon","DRAGON","Mythical creature"],["Elephant.jpg","ELEPHANT","Large mammal"]]
    
    let imageMapping: [String: String] = [
        "AIRPLANE": "airplane.jpg",
        "BANANA": "banana.jpg",
        "CARROT": "carrot.jpg",
        "DRAGON": "dragon.jpg",
        "ELEPHANT": "elephant.jpg"
    ]
    
    
    var word = ""
    var lettersGuessed = ""
    var imageNumber = 0
    var maxNumOfWrongGuesses = 10
    var totalWordsGuessed = 0
    var totalWordsRemaining = 0
    var numberOfGuesses = 0
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    @IBOutlet weak var PlayAgainButton: UIButton!
    
    @IBOutlet weak var GuessButton: UIButton!
    
    
    
    
    @IBOutlet weak var hintLabel: UILabel!
    
    
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var imageDisplay: UIImageView!
    
    
    
    
    
    
    // Call this method in viewDidLoad to initialize the UI
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        word = input[imageNumber][1]
                        
                wordsGuessedLabel.text = "Total number of words guessed successfully: 0"
                wordsRemainingLabel.text = "Total number of words remaining in game: \(input.count)"
                totalWordsLabel.text = "Total number of words in the game: \(input.count)"
                userGuessLabel.text = "_ _ _ _ _"
                hintLabel.text = "Hint: \(input[imageNumber][2])"
                guessCountLabel.text = "You have made 0 guesses"
                GuessButton.isEnabled = false
                statusLabel.text = ""
        
    }
    
    func updateUnderscores() {
            
            for _ in word{
                       userGuessLabel.text! += "_ "
                   }

        }
      
        func setupGame() {
           
            word = input[imageNumber][1]
            lettersGuessed = ""
            userGuessLabel.text = String(repeating: "_ ", count: word.count)
            guessLetterField.text = ""
            hintLabel.text = "Hint: " + input[imageNumber][2]
            statusLabel.text = ""
            updateTotalWordsLabel()

        }
        func updateTotalWordsLabel() {
            wordsGuessedLabel.text = "Total number of words guessed successfully: \(totalWordsGuessed)"
            wordsRemainingLabel.text = "Total number of words remaining in game: \(totalWordsRemaining)"
            totalWordsLabel.text = "Total number of words in the game: \(input.count)"

        }
    
    
    
    
    
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        
        let letter = guessLetterField.text!
                      lettersGuessed = lettersGuessed + letter
                       var revealedWord = ""
                       self.numberOfGuesses = self.numberOfGuesses + 1
                       guessCountLabel.text = "You have made \(numberOfGuesses) guesses"
               
                      for l in word{
                          if lettersGuessed.contains(l){
                              revealedWord += "\(l)"
                          }
                          else{
                              revealedWord += "_ "
                           
                          }
                           
                      }
               userGuessLabel.text! = revealedWord
             
               GuessButton.isEnabled = false
               if !userGuessLabel.text!.contains("_") {
                                   PlayAgainButton.isHidden = false
                                   GuessButton.isEnabled = false
                                   totalWordsGuessed += 1
                                   totalWordsRemaining = input.count  - totalWordsGuessed

                                   updateTotalWordsLabel()
                                   guessCountLabel.text = "Wow! You have made \(numberOfGuesses) guesses to guess the word!"
       //
                   imageDisplay.image = UIImage(named: input[imageNumber][0])
                               }

               if (numberOfGuesses  > maxNumOfWrongGuesses){
                   guessCountLabel.text = "You have used all the available guesses, Please play again"

                   self.PlayAgainButton.isHidden=false
                   imageNumber -= 1
               }

                               if totalWordsGuessed == 1 {
                                   totalWordsRemaining = input.count  - 1
                                   
               } else if totalWordsGuessed == 2 {
                                   totalWordsRemaining = input.count  - 2
               }else if totalWordsGuessed == 3 {
                                   totalWordsRemaining = input.count  - 3
               }else if totalWordsGuessed == 4 {
                                   totalWordsRemaining = input.count  - 4
               }else if totalWordsGuessed == 5 {
               totalWordsRemaining = input.count  - 5
                   
               }
               guessLetterField.text="";
        
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        
        
        self.numberOfGuesses=0
                guessCountLabel.text = ""
                        PlayAgainButton.isHidden = true
                        
                        lettersGuessed = ""
                        imageNumber += 1
                self.imageDisplay.image = nil

                if imageNumber == input.count{
                        
                            totalWordsGuessed=0
                            totalWordsRemaining = input.count - totalWordsGuessed
                            updateTotalWordsLabel()
                            self.guessLetterField.text=""
                            statusLabel.text = "Congratulations! You are done with the game. Please start over again"
                                                hintLabel.isHidden = true
                            hintLabel.text = ""
                            self.userGuessLabel.text=""
                           
                            self.imageDisplay.image=UIImage(named: "alldone")
                            PlayAgainButton.isHidden = false
                    word = input[0][1]
                    hintLabel.isHidden = false;

                }

                
                else if imageNumber >= input.count{
                    
                    numberOfGuesses = 0
                    guessCountLabel.text = ""
                    PlayAgainButton.isHidden = true
                    lettersGuessed = ""
                    imageNumber = 0
                    totalWordsGuessed = 0
                    totalWordsRemaining = input.count - totalWordsGuessed
                    updateTotalWordsLabel()
                    guessLetterField.text = ""
                    statusLabel.text = ""
                    imageDisplay.image = nil
                    hintLabel.isHidden = false
                    hintLabel.text = "Hint: \(input[imageNumber][2])"
                    userGuessLabel.text = "_ _ _ _ _"
                    GuessButton.isEnabled = false
          
                }
                
                else{
                    setupGame()
                }
        
        
    }
    
    
    
    
    
    
    
    @IBAction func guessLetterChanged(_ sender: UITextField) {
        
        
        if let textEntered = guessLetterField.text {
                                           let trimmedText = String(textEntered.last ?? " ").trimmingCharacters(in: .whitespaces)

                    guessLetterField.text = trimmedText
                    GuessButton.isEnabled = !trimmedText.isEmpty
                    
                    
                }
        
    }
    
    
    
}
