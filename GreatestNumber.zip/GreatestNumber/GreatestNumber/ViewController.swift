//
//  ViewController.swift
//  GreatestNumber
//
//  Created by Yerragunta,Puruhuthika on 8/31/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var input2OL: UITextField!
    
    
    
    @IBOutlet weak var outputOl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func BtnClicked(_ sender: UIButton) {
        
        var input = Int(inputOL.text!)
        var input2 = Int(input2OL.text!)
        if(input!>input2!){
            outputOl.text = "1st number is greatest!"
            
        }
        else
        {
            outputOl.text = "2nd number is greatest!"
        }
    }
    
    
    

}

