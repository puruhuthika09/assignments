//
//  ViewController.swift
//  tableViewDemo
//
//  Created by Yerragunta,Puruhuthika on 11/9/23.
//

import UIKit


class Product{
    var name : String?
    var category : String?
    init(name: String? = nil, category: String? = nil) {
        self.name = name
        self.category = category
    }
    
}
class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return the no.of products  [count of an array]
        return productsArray.count
     
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //create the cell , pouplate the cell and  return the cell
        var cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "reusableCell",for: indexPath)
        cell.textLabel?.text = productsArray[indexPath.row].name
        return cell
        
        
    }
    
var productsArray = [Product]()

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let product1 = Product(name : "MacBookAir",category : "Laptop")
        let product2 = Product(name : "iphone",category : "Cell Phone")
        let product3 = Product(name : "AirPods",category : "Accessories")
        let product4 = Product(name : "iWatch",category : "Accessories")
        let product5 = Product(name : "Charger",category : "Accessories")
        
        
        productsArray.append(product1)
        productsArray.append(product2)
        
        productsArray.append(product3)
        
        productsArray.append(product4)
        productsArray.append(product5)
        
        tableViewOutlet.delegate = self
        tableViewOutlet.dataSource = self
        
        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var tableViewOutlet: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if(transition  == "productDetails"){
            let destination = segue.destination as!
            ProductsDescriptionViewController
            destination.product = productsArray[(tableViewOutlet.indexPathForSelectedRow?.row)!]
            
            
        }
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
}

