//
//  ResultViewController.swift
//  DiscountAppController
//
//  Created by Yerragunta,Puruhuthika on 10/31/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var displayAmountOL: UILabel!
    
    
    @IBOutlet weak var displayDiscOL: UILabel!
    
    
    @IBOutlet weak var displayPriceOL: UILabel!
    
    var amount = ""
    var discount = ""
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayAmountOL.text! += amount
        displayDiscOL.text! += discount
        displayPriceOL.text! += String(priceAfterDiscount)
        // Do any additional setup after loading the view.
    }
    

    /*
     
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
