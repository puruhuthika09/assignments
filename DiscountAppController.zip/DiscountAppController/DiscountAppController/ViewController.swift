//
//  ViewController.swift
//  DiscountAppController
//
//  Created by Yerragunta,Puruhuthika on 10/31/23.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var amountOL: UITextField!
    
    
    @IBOutlet weak var discountOL: UITextField!
    
    var priceAfterDiscount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func resultBtn(_ sender: UIButton) {
        //Read the data from text fields
        //double the amount
        var amount = Double(amountOL.text!)
        var discount = Double(discountOL.text!)
        
        //calculate the discount
         priceAfterDiscount = amount! - ((amount!*discount!)/100)
        
        
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "resultSegue"{
            var destination = segue.destination as!
            ResultViewController
            destination.amount = amountOL.text!
            destination.discount = discountOL.text!
            destination.priceAfterDiscount = priceAfterDiscount
        }
        
    }
    
}

