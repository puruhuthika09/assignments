//
//  ViewController.swift
//  collectionViewApp
//
//  Created by Y Puruhuthika on 11/30/23.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return movies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = CollectionViewOutlet.dequeueReusableCell(withReuseIdentifier: "movie", for: indexPath) as! MovieCollectionViewCell
        cell.assignMovie(with: movies[indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        assignMovieDetails(index : indexPath)
    }
    func  assignMovieDetails(index : IndexPath){
        titleOutlet.text = "Movie Title: \(movies[index.row].title)"
    }

    
    @IBOutlet weak var CollectionViewOutlet: UICollectionView!
    
    
    
    @IBOutlet weak var titleOutlet: UILabel!
    
    
    @IBOutlet weak var yearOL: UILabel!
    
    @IBOutlet weak var ratingOL: UILabel!
    
    
    @IBOutlet weak var boxOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        CollectionViewOutlet.delegate = self
        CollectionViewOutlet.dataSource = self
        // Do any additional setup after loading the view.
    }


}

