//
//  MovieCollectionViewCell.swift
//  collectionViewApp
//
//  Created by Y Puruhuthika on 11/30/23.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOutlet: UIImageView!
    func assignMovie(with movie: Movie){
        imageViewOutlet.image = movie.image
    }
    
}
