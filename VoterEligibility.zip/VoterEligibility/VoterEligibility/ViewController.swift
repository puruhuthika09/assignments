//
//  ViewController.swift
//  VoterEligibility
//
//  Created by Yerragunta,Puruhuthika on 9/5/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var inputOL: UITextField!
    
    @IBOutlet weak var outputOL: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


  
    @IBAction func BtnClicked(_ sender: UIButton) {
        
        var input =  Double(inputOL.text!)
        if(input!>=18)
        {
            outputOL.text = "You are Eligible!"
            
        }
        else{
            outputOL.text = "You are not Eligible!"
        }
    }
}

