//
//  ViewController.swift
//  wordGuessApp
//
//  Created by Yerragunta,Puruhuthika on 10/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var displayLabel: UILabel!
   
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var letterEntered: UITextField!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var ChcekButton: UIButton!
    
    @IBOutlet weak var playAgainButton: UIButton!
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }

    @IBAction func ChcekButtonClicked(_ sender: Any) {
        
    }
    
    @IBAction func playAgainButtonClicked(_ sender: UIButton) {
    }
    
    @IBAction func enterLabelChanged(_ sender: UITextField) {
    }
    
}

