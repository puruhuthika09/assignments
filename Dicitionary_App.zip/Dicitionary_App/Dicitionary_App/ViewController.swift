//
//  ViewController.swift
//  Dicitionary_App
//
//  Created by Yerragunta,Puruhuthika on 11/28/23.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //return the no.of products  [count of an array]
        return words.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //create the cell , pouplate the cell and  return the cell
        var cell = tableViewOutlet.dequeueReusableCell(withIdentifier: "reusableCell",for: indexPath)
        cell.textLabel?.text = words[indexPath.row][0]
        return cell
        
        
    }
    var words = [
        ["Benevolent 🤗","Well-Meanijng and kindly."],
        ["Courage", " The ablity to do something that frightens one."],
        ["Hope","A Feeling of expectation and desire for particular thing to happen"],
    ]

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
        
        
                tableViewOutlet.delegate = self
                tableViewOutlet.dataSource = self
        // Do any additional setup after loading the view.
    }
    
    
    @IBOutlet weak var tableViewOutlet: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        var transition = segue.identifier
        if(transition  == "ProductDetails"){
            let destination = segue.destination as!
            Product_ViewController
            destination.words =
            words[(tableViewOutlet.indexPathForSelectedRow?.row)!]
            
            
        }
        
    }
    
}
