//
//  ViewController.swift
//  Yerragunta_Assignment02
//
//  Created by Y PURUHUTHIKA on 9/10/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameOutlet: UITextField!
    
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func SubmitBTN(_ sender: UIButton) {
        // Read values from Textfields
        if let name = nameOutlet.text, let billAmountt = billAmountOutlet.text, let tipPercentagee = tipPercentageOutlet.text,
            let billAmount = Double(billAmountt),let tipPercentage = Double(tipPercentagee){
            
            
            let tipAmount = (billAmount * tipPercentage)/100
            let totalAmount = billAmount + tipAmount
            
            //Printing the result
            nameLabel.text = "Name: \(name)"
            billAmountLabel.text = "Bill Amount: $\(billAmount)"
            tipAmountLabel.text = "Tip Amount: $\(tipAmount)"
            totalAmountLabel.text = "Total Amount: $\(totalAmount)"
            
        }
    }
    
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        
        //clearing the text fileds
        
        
        //clearing lables
        
        nameLabel.text = ""
        billAmountLabel.text = ""
        tipAmountLabel.text = ""
        totalAmountLabel.text = ""
        
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        
        
    }
}
