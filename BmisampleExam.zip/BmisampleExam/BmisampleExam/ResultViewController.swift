//
//  ResultViewController.swift
//  BmisampleExam
//
//  Created by Y PURUHUTHIKA on 11/13/23.
//

import UIKit

class ResultViewController: UIViewController {
    
    
    @IBOutlet weak var displayWeightOL: UILabel!
    
    
    @IBOutlet weak var displayHeightOL: UILabel!
    
    
    @IBOutlet weak var displayBMI: UILabel!
    
    
    
    @IBOutlet weak var displayImage: UIImageView!
    var height = ""
    var weight = ""
    
    var BMI = 0.0
    var imageName = ""
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayWeightOL.text! += weight
        displayHeightOL.text! += height
        displayBMI.text! += String(BMI)
        
        displayImage.image = UIImage(named: imageName)
        //this for side image
        
        //displayImage.frame.origin.x = view.frame.maxX
        
        // Do any additional setup after loading the view.
    }
    //this works ,display the image and also blink many times
//    override func viewDidAppear(_ animated: Bool) {
//        super.viewDidAppear(animated)
//        
//         //Perform the image-specific animation
//       // animateResultImage(imageName)
//        UpdateandAnimate(imageName)
//    }
//    
    
//            func animateResultImage(_ imageName: String) {
//                // Make the current image as opaque (alpha is zero)
//                displayImage.alpha = 0
//    
//                // Assign the new image as animation and make it transparent (alpha should be 1)
//                UIView.animate(withDuration: 1, delay: 0.5, options: [.autoreverse, .repeat], animations: {
//                    self.displayImage.alpha = 1
//                    self.displayImage.image = UIImage(named: imageName)
//                })
//    }
//    
    
    
    
    
//this works ,display the image and also blink one time
    func UpdateandAnimate(_ imageName:String){
        //Make the current image as opaque.(alpha is zero)
        UIView.animate(withDuration: 1, animations: {
            self.displayImage.alpha = 0
        })
        // Assign the new image as animation and make it transparent.(alpha should be 1)
        UIView.animate(withDuration: 1, delay: 0.5,animations: {
            self.displayImage.alpha = 1
            self.displayImage.image = UIImage(named: imageName)
        })
        
        
    }
    
    
    
    
    //yes it is working for phone out of screen
    
//    override func viewDidAppear(_ animated: Bool) {
//            super.viewDidAppear(animated)
//
//            // Animate the image coming from the right side of the screen to the center
//            UIView.animate(withDuration: 1, animations: {
//                self.displayImage.center.x = self.view.center.x
//            })
//        }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
